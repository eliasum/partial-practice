﻿using DevExpress.XtraGrid.Views.Grid;
using Greenatom.Moc.Vendor;
using mpdv.Common.Data.DataLogic;
using mpdv.Common.Data.DataManager;
using mpdv.Common.GUI.ApplicationFramework;
using mpdv.Common.GUI.Grids;
using mpdv.Common.mpdvSystem.CodeManagementFramework;
using mpdv.Common.Util;
using mpdv.Common.Util.GUI;
using mpdv.Common.Util.Ioc;
using mpdv.plugins.GridApplication;
using Mpdv.Communication;
using Mpdv.Communication.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mpdv.plugins.ApplicationScripts {
  public partial class U_OV {

    private static List<ParameterItem> parameterItemsListPP;
    private static List<ParameterItem> parameterItemsListUnlinkPP;
    private static List<ParameterItem> parameterItemsListLinkPP;
    [ScriptPlugin("U_OVAfterShowApplication", "mpdv.plugins.ApplicationScripts.U_OV", nameof(U_OV_ShowApplication), "", 0, 1, 0, 0)]
    public static object U_OV_ShowApplication(CodeDescriptorArgs args) {
      if (!(args.Values["ApplicationContainer"] is ApplicationContainer mainApp)) return null;
      if (!mainApp.ApplicationPlugins.TryGetValue("OrderPP", out IApplicationPlugin gridPluginOrderPP) || !(gridPluginOrderPP is Grid gridOrderPP)) return null;
      if (!mainApp.ApplicationPlugins.TryGetValue("OrderUnlinkPP", out IApplicationPlugin gridPluginUnlinkpp) || !(gridPluginUnlinkpp is Grid gridUnlinkpp)) return null;
      if (!(gridOrderPP.GetControl("") is mpdvGrid gridOrder)) return null;
      mpdvBandedGridView orderPPGridView = gridOrder.MainView as mpdvBandedGridView;
      orderPPGridView.CustomDrawCell += U_OV.GridViewCustomDrawCell;
      return null;

    }

    [ScriptPlugin("LinkCallScript", "mpdv.plugins.ApplicationScripts.U_OV", nameof(LinkCallScript), "", 0, 1, 0, 0)] // LinkCallScript - наименование скрипта у кнопки.
    public static Object LinkCallScript(CodeDescriptorArgs args) {
      if (!(args.Values["ApplicationContainer"] is ApplicationContainer mainApp)) return null;  // Получаем основное окно формы приложения.
      if (!mainApp.ApplicationPlugins.TryGetValue("OrderPP", out IApplicationPlugin gridPluginOrderPP) || !(gridPluginOrderPP is Grid gridOrderPP)) return null;  // Получаю грид с наименованием OrderPP. 
      if (!mainApp.ApplicationPlugins.TryGetValue("OrderUnlinkPP", out IApplicationPlugin gridPluginUnlinkpp) || !(gridPluginUnlinkpp is Grid gridUnlinkpp)) return null; // Получаю грид с наименованием OrderUnlinkPP.
      if (!mainApp.ApplicationPlugins.TryGetValue("OrderLinkPP", out IApplicationPlugin gridPluginOrderLinkPP) || !(gridPluginOrderLinkPP is Grid gridOrderLinkPP)) return null; // Получаю грид с наименованием OrderLinkPP.
      // Основные проверки что есть записи в таблицах и строка выбрана.
      if (!(gridOrderPP.GetControl("") is mpdvGrid gridOrder)) return null;
      if (!(gridOrder.DataSource is System.Data.DataView dataGridOrder)) {
        mpdvMessageBox.ShowError("Укажите заказ в таблице объемных заказов");
        return null;
      }
      if (!(gridUnlinkpp.GetControl("") is mpdvGrid gridUnlink)) return null;
      if (!(gridOrderLinkPP.GetControl("") is mpdvGrid gridOrderLink)) return null;
      if (!(gridUnlink.DataSource is System.Data.DataView dataGridUnlink)) {
        mpdvMessageBox.ShowError("Укажите заказ в таблице производтвенных заказов");
        return null;
      }
      if (dataGridUnlink.Table.Rows.Count == 0) {
        mpdvMessageBox.ShowError("Укажите заказ в таблице производтвенных заказов");
        return null;
      }
      if (!(((mpdvDataTable)dataGridOrder.Table).RowSelection is mpdvDataTable dataOrder)) return null;
      if (dataOrder.Rows.Count > 1) {
        mpdvMessageBox.ShowError("В таблице объемных заказов выберете один заказ");
        return null;
      }
      String planAuftrag = dataOrder.Rows[0]["u_ov.list_pp.plan_auftrag"].ToString();

      if (string.IsNullOrEmpty(planAuftrag)) {
        mpdvMessageBox.ShowError("В таблице объемных заказов выберете один заказ");
        return null;
      }
      if (!(((mpdvDataTable)dataGridUnlink.Table).RowSelection is mpdvDataTable dataUnlink)) return null;
      if (!(gridOrderPP.GetControl("") is mpdvGrid mpdvGridOrderPP) || !(mpdvGridOrderPP.MainView is GridView gridView)) return null;
      // Спрашиваем пользователя что выбранные записи верны.
      DialogResult dialogResult = mpdvMessageBox.ShowQuestion($"Вы действительно хотите привязать {dataUnlink.Rows.Count} производственных заказов к {planAuftrag}", MessageBoxButtons.YesNoCancel, DialogResult.Cancel);
      if (!(DialogResult.Yes == dialogResult)) return null;
      // Вывод SplashScreen которое не позволяет пользователю бегать по приложению.
      SplashScreenManagerEx splash = SplashScreenManagerEx.Create(mainApp);
      try {
        // Вызов сервиса и передачи параметров
        splash.SurroundWithSplashScreen(Link(dataUnlink, planAuftrag));
      } catch (AggregateException agex) {
        foreach (var ex in agex.InnerExceptions) {
          if (ex.InnerException is LegacyServerErrorException legacyEx) {
            mpdvMessageBox.ShowError(legacyEx.LongText);
          }

        }
      } finally {
        // Обновление гридов.
        if (mainApp.DataControllers.TryGetValue("U_OVListLink", out mpdvDataController controllerLink) && parameterItemsListLinkPP.Count > 0) {
          controllerLink.Execute(parameterItemsListLinkPP);
          gridOrderLink.RefreshDataSource();
        }
        if (mainApp.DataControllers.TryGetValue("U_OVListUnlink", out mpdvDataController controllerUnlink) && parameterItemsListUnlinkPP.Count > 0) {
          controllerUnlink.Execute(parameterItemsListUnlinkPP);
          gridUnlink.RefreshDataSource();
        }

        object curentRowId = null;
        if (gridView.FocusedRowHandle >= 0) {
          curentRowId = gridView.GetRowCellValue(gridView.FocusedRowHandle, "u_ov.list_pp.auftrag_nr");
        }
        gridOrderPP.DataController.RequestData();

        if (curentRowId != null) {
          // Прыгаем на выбранную строку.
          for (int i = 0; i < gridView.RowCount; i++) {
            var idValue = gridView.GetRowCellValue(i, "u_ov.list_pp.auftrag_nr");
            if (idValue != null && idValue.Equals(curentRowId)) {
              gridView.FocusedRowHandle = i;
              gridView.SelectRow(i);
              gridView.MakeRowVisible(i);
              break;
            }
          }
        }
      }
      return null;
    }

    [ScriptPlugin("UnlinkCallScript", "mpdv.plugins.ApplicationScripts.U_OV", nameof(UnlinkCallScript), "", 0, 1, 0, 0)]
    public static Object UnlinkCallScript(CodeDescriptorArgs args) {
      if (!(args.Values["ApplicationContainer"] is ApplicationContainer mainApp)) return null;
      if (!mainApp.ApplicationPlugins.TryGetValue("OrderLinkPP", out IApplicationPlugin gridPluginOrderLinkPP) || !(gridPluginOrderLinkPP is Grid gridOrderLinkPP)) return null;
      if (!mainApp.ApplicationPlugins.TryGetValue("OrderPP", out IApplicationPlugin gridPluginOrderPP) || !(gridPluginOrderPP is Grid gridOrderPP)) return null;
      if (!mainApp.ApplicationPlugins.TryGetValue("OrderUnlinkPP", out IApplicationPlugin gridPluginUnlinkpp) || !(gridPluginUnlinkpp is Grid gridUnlinkpp)) return null;
      if (!(gridOrderLinkPP.GetControl("") is mpdvGrid gridOrderLink)) return null;
      if (!(gridOrderPP.GetControl("") is mpdvGrid gridOrder)) return null;
      if (!(gridUnlinkpp.GetControl("") is mpdvGrid gridUnlink)) return null;
      if (!(gridOrderLink.DataSource is System.Data.DataView dataOrderLink)) {
        mpdvMessageBox.ShowError("Укажите заказ в таблице связанных производтсвенных заказов.");
        return null;
      }
      if (!(((mpdvDataTable)dataOrderLink.Table).RowSelection is mpdvDataTable dataUnlink)) return null;
      if (!(gridOrderPP.GetControl("") is mpdvGrid mpdvGridOrderPP) || !(mpdvGridOrderPP.MainView is GridView gridView)) return null;
      String planAuftrag = dataUnlink.Rows[0]["u_ov.list_link.plan_auftrag"].ToString();
      DialogResult dialogResult = mpdvMessageBox.ShowQuestion($"Вы действительно хотите отвязать {dataUnlink.Rows.Count} производственных заказов у {planAuftrag}", MessageBoxButtons.YesNoCancel, DialogResult.Cancel);
      if (!(DialogResult.Yes == dialogResult)) return null;
      SplashScreenManagerEx splash = SplashScreenManagerEx.Create(mainApp);
      try {
        splash.SurroundWithSplashScreen(Unlink(dataUnlink));
      } catch (AggregateException agex) {
        foreach (var ex in agex.InnerExceptions) {
          if (ex.InnerException is LegacyServerErrorException legacyEx) {
            mpdvMessageBox.ShowError(legacyEx.LongText);
          }

        }
      } finally {
        if (mainApp.DataControllers.TryGetValue("U_OVListLink", out mpdvDataController controllerLink) && parameterItemsListLinkPP.Count > 0) {
          controllerLink.Execute(parameterItemsListLinkPP);
          gridOrderLink.RefreshDataSource();
        }
        if (mainApp.DataControllers.TryGetValue("U_OVListUnlink", out mpdvDataController controllerUnlink) && parameterItemsListUnlinkPP.Count > 0) {
          controllerUnlink.Execute(parameterItemsListUnlinkPP);
          gridUnlink.RefreshDataSource();
        }


        object curentRowId = null;
        if (gridView.FocusedRowHandle >= 0) {
          curentRowId = gridView.GetRowCellValue(gridView.FocusedRowHandle, "u_ov.list_pp.auftrag_nr");
        }
        gridOrderPP.DataController.RequestData();

        if (curentRowId != null) {
          for (int i = 0; i < gridView.RowCount; i++) {
            var idValue = gridView.GetRowCellValue(i, "u_ov.list_pp.auftrag_nr");
            if (idValue != null && idValue.Equals(curentRowId)) {
              gridView.FocusedRowHandle = i;
              gridView.SelectRow(i);
              gridView.MakeRowVisible(i);
              break;
            }
          }
        }

      }
      return null;
    }

    [ScriptPlugin("U_OVListLinkBeforeRequestData", "mpdv.plugins.ApplicationScripts.U_OV", nameof(U_OVListLinkBeforeRequestData), "", 0, 1, 0, 0)]
    public static object U_OVListLinkBeforeRequestData(CodeDescriptorArgs args) {
      if (!(args.Values["ParameterList"] is List<ParameterItem> inListParameterItem)) return null;
      parameterItemsListLinkPP = inListParameterItem;
      return null;
    }

    [ScriptPlugin("U_OVListPPBeforeRequestData", "mpdv.plugins.ApplicationScripts.U_OV", nameof(U_OVListPPBeforeRequestData), "", 0, 1, 0, 0)]
    public static object U_OVListPPBeforeRequestData(CodeDescriptorArgs args) {
      if (!(args.Values["ParameterList"] is List<ParameterItem> inListParameterItem)) return null;
      parameterItemsListPP = inListParameterItem;
      return null;
    }

    [ScriptPlugin("U_OVListUnlinkBeforeRequestData", "mpdv.plugins.ApplicationScripts.U_OV", nameof(U_OVListUnlinkBeforeRequestData), "", 0, 1, 0, 0)]
    public static object U_OVListUnlinkBeforeRequestData(CodeDescriptorArgs args) {
      if (!(args.Values["ParameterList"] is List<ParameterItem> inListParameterItem)) return null;
      parameterItemsListUnlinkPP = inListParameterItem;
      return null;
    }

    [ScriptPlugin("U_OVCreateorderAfterUpdateAfterProcessExecution", "mpdv.plugins.ApplicationScripts.U_OV", nameof(U_OVCreateOrderPostScript), "", 0, 1, 0, 0)]
    public static object U_OVCreateOrderPostScript(CodeDescriptorArgs args) {
      if (!(args.Caller is ApplicationContainerForEdit { ParentContainer: { } mainApp })) return null;
      if (!mainApp.ApplicationPlugins.TryGetValue("OrderPP", out IApplicationPlugin pluginOrderPP) || !(pluginOrderPP is Grid gridOrderPP)) return null;
      if (!mainApp.ApplicationPlugins.TryGetValue("OrderLinkPP", out IApplicationPlugin gridPluginOrderLinkPP) || !(gridPluginOrderLinkPP is Grid gridOrderLinkPP)) return null;
      if (!mainApp.ApplicationPlugins.TryGetValue("OrderUnlinkPP", out IApplicationPlugin gridPluginUnlinkpp) || !(gridPluginUnlinkpp is Grid gridUnlinkpp)) return null;



      if (!(gridOrderPP.GetControl("") is mpdvGrid mpdvGridOrderPP) || !(mpdvGridOrderPP.MainView is GridView gridView)) return null;
      var row = gridView.GetFocusedRow();
      object curentRowId = null;
      if (gridView.FocusedRowHandle >= 0) {
        curentRowId = gridView.GetRowCellValue(gridView.FocusedRowHandle, "u_ov.list_pp.auftrag_nr");
      }
      gridOrderPP.DataController.RequestData();

      if (curentRowId != null) {
        for (int i = 0; i < gridView.RowCount; i++) {
          var idValue = gridView.GetRowCellValue(i, "u_ov.list_pp.auftrag_nr");
          if (idValue != null && idValue.Equals(curentRowId)) {
            gridView.FocusedRowHandle = i;
            gridView.SelectRow(i);
            gridView.MakeRowVisible(i);
            break;
          }
        }
      }

      if (!(gridUnlinkpp.GetControl("") is mpdvGrid gridUnlink)) return null;
      if (!(gridOrderLinkPP.GetControl("") is mpdvGrid gridOrderLink)) return null;
      if (mainApp.DataControllers.TryGetValue("U_OVListLink", out mpdvDataController controllerLink) && parameterItemsListLinkPP.Count > 0) {
        controllerLink.Execute(parameterItemsListLinkPP);
        gridOrderLink.RefreshDataSource();
      }
      if (mainApp.DataControllers.TryGetValue("U_OVListUnlink", out mpdvDataController controllerUnlink) && parameterItemsListUnlinkPP.Count > 0) {
        controllerUnlink.Execute(parameterItemsListUnlinkPP);
        gridUnlink.RefreshDataSource();
      }

      return null;
    }


    private static Func<Task> Unlink(mpdvDataTable dataTable) {
      return async () => {
        foreach (DataRow row in dataTable.Rows) {
          String chargenn = row["u_ov.list_link.chargennr"].ToString();
          String aunr = row["u_ov.list_link.auftrag_nr"].ToString();
          String artikel = row["u_ov.list_link.artikel"].ToString();
          String planAuftrag = row["u_ov.list_link.plan_auftrag"].ToString();
          List<Exception> exceptions = new List<Exception>();
          try {
            IRequestConfiguration serviceConfigList = ServiceConfigList("U_OV.unlink");
            serviceConfigList.Parameters.SetOrAdd("order.batch_number", Operator.EqualTo, chargenn);
            serviceConfigList.Parameters.SetOrAdd("order.id", Operator.EqualTo, aunr);
            serviceConfigList.Parameters.SetOrAdd("order.article", Operator.EqualTo, artikel);
            serviceConfigList.Parameters.SetOrAdd("order.plannedorder", Operator.EqualTo, planAuftrag);
            _ = ServiceList().CreateAsyncRequest(serviceConfigList).GetResultAsync().Result;
          } catch (InvalidCastException ex) {
            Tracing.Write(TraceLevel.GeneralException, TraceMember.Exception, "U_OV", "UnlinkCallScript_Click", ex.Message);
          } catch (DataLogicException ex2) {
            Tracing.Write(TraceLevel.GeneralException, TraceMember.Exception, "U_OV", "UnlinkCallScript_Click", ex2.Message);
          } catch (mpdvWebServiceRequestDataException ex3) {
            ex3.HandleError("mpdv.plugins.ApplicationScripts.U_OV.UnlinkCallScript_Click");
            exceptions.Add(ex3);
          } catch (mpdvWebServiceNotAvailableException ex4) {
            ex4.HandleError("mpdv.plugins.ApplicationScripts.U_OV.UnlinkCallScript_Click");
          } catch (IndexOutOfRangeException ex5) {
            Tracing.Write(TraceLevel.GeneralException, TraceMember.Exception, "U_OV", "UnlinkCallScript_Click", ex5.Message);
          }
          if (exceptions.Count > 0) {
            throw new AggregateException("Bapi вернула ошибку.", exceptions);
          }
        }
      };
    }

    private static Func<Task> Link(mpdvDataTable dataTable, String planAuftrag) {
      return async () => {
        foreach (DataRow row in dataTable.Rows) {
          String chargenn = row["u_ov.list_unlink.chargennr"].ToString();
          String aunr = row["u_ov.list_unlink.auftrag_nr"].ToString();
          String artikel = row["u_ov.list_unlink.artikel"].ToString();
          List<Exception> exceptions = new List<Exception>();
          try {
            IRequestConfiguration serviceConfigList = ServiceConfigList("U_OV.link");
            serviceConfigList.Parameters.SetOrAdd("order.batch_number", Operator.EqualTo, chargenn);
            serviceConfigList.Parameters.SetOrAdd("order.id", Operator.EqualTo, aunr);
            serviceConfigList.Parameters.SetOrAdd("order.article", Operator.EqualTo, artikel);
            serviceConfigList.Parameters.SetOrAdd("order.plannedorder", Operator.EqualTo, planAuftrag);
            _ = ServiceList().CreateAsyncRequest(serviceConfigList).GetResultAsync().Result;
          } catch (InvalidCastException ex) {
            Tracing.Write(TraceLevel.GeneralException, TraceMember.Exception, "U_OV", "LinkCallScript_Click", ex.Message);
          } catch (DataLogicException ex2) {
            Tracing.Write(TraceLevel.GeneralException, TraceMember.Exception, "U_OV", "LinkCallScript_Click", ex2.Message);
          } catch (mpdvWebServiceRequestDataException ex3) {
            ex3.HandleError("mpdv.plugins.ApplicationScripts.U_OV.LinkCallScript_Click");
            exceptions.Add(ex3);
          } catch (mpdvWebServiceNotAvailableException ex4) {
            ex4.HandleError("mpdv.plugins.ApplicationScripts.U_OV.LinkCallScript_Click");
          } catch (IndexOutOfRangeException ex5) {
            Tracing.Write(TraceLevel.GeneralException, TraceMember.Exception, "U_OV", "LinkCallScript_Click", ex5.Message);
          }
          if (exceptions.Count > 0) {
            throw new AggregateException("Bapi вернула ошибку.", exceptions);
          }

        }
      };

    }


    private static IRequestFactory ServiceList() {
      var serviceList = ServiceLocator.GetInstance<IRequestFactory>();
      return serviceList;
    }

    private static IRequestConfiguration ServiceConfigList(String service) {
      var serviceConfigList = ServiceList().GetDefaultConfiguration(service);
      return serviceConfigList;
    }
  }
}
