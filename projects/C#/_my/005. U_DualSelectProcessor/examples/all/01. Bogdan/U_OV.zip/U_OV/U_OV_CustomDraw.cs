﻿using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using System;
using System.Drawing;

namespace mpdv.plugins.ApplicationScripts {
  public static partial class U_OV {
    private static void GridViewCustomDrawFooterCell(object sender, FooterCellCustomDrawEventArgs e) {
      if (e.Column.FieldName != "test") return;
      if (!(sender is GridView view)) return;

    }

    private static void GridViewCustomDrawCell(Object sender, RowCellCustomDrawEventArgs e) {
      if (e.Column.FieldName == "u_ov.list_pp.plan_progress_bar") {
        DrawPlanProgressBar(e);
      }
    }

    private static void DrawPlanProgressBar(RowCellCustomDrawEventArgs e) {
      Int32 progress = e.CellValue switch
      {
        Int32 intValue => intValue,
        Decimal decimalValue => Decimal.ToInt32(decimalValue),
        _ => 0
      };

      Rectangle rect = e.Bounds;
      rect.Width = (Int32)(progress * rect.Width / 100.00);
      e.Cache.FillRectangle(GetUptimeColor(progress), rect);
      e.Appearance.DrawString(e.Cache, e.DisplayText, e.Bounds);
      e.Handled = true;
    }

    private static Color GetUptimeColor(Int32 progress) {
      if (progress > 100) progress = 100;
      if (progress < 0) progress = 0;
      Int32 red = 255, green = 255, blue = 255;
      const Double step = 2 * 255 / 100.00;
      if (progress <= 50) {
        blue -= (Int32)Math.Ceiling(progress * step);
      } else {
        red -= (Int32)Math.Ceiling((progress - 50) * step);
        if (red < 0) red = 0;
        blue = 0;
      }

      return Color.FromArgb(red, green, blue);
    }
  }
}
